// OxideRevolution state reader. ESP-only: hp has no flat backing field in this build (PlayerVitals is property-driven,
// needs a live method-invoke to read reliably) -- not implemented, left out of PlayerInfo on purpose rather than faked.
#pragma once
#include "il2cpp.h"
#include "vmath.h"
#include <string>
#include <vector>

struct PlayerInfo {
    uint64_t obj = 0;
    Vec3 pos;                 // worldCameraRoot world position (eye level)
    bool local = false;
    bool friendly = false;    // Yd.isFriend
    bool teammate = false;    // Yd.isTeammate
    char name[32] = {0};
};

struct Snapshot {
    bool valid = false;
    bool haveLocal = false;
    Vec3 localPos;
    std::vector<PlayerInfo> players;
};

class Game {
public:
    Game(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool resolve();
    bool update(Snapshot& s);
    const char* status() const { return status_.c_str(); }
    int classes_seen() const { return il_.classes_seen(); }
    void set_scan_gap(double s) { il_.set_scan_gap(s); }
private:
    bool world_pos(uint64_t transform, Vec3& out);
    bool world_pos_nat(uint64_t nativeTransform, Vec3& out);
    IMem& m_;
    Il2 il_;
    uint64_t kPM_ = 0, kYd_ = 0, kText_ = 0, kNetId_ = 0;
    std::vector<uint64_t> players_;
    double nextScan_ = 0;
    std::string status_ = "init";
};
