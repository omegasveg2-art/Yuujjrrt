package rev.exe;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Tabbed, draggable, immediate-feeling menu -- deliberately not the floating-button+single-panel style of
 *  Astral.exe: top tab strip (ESP / RADAR / FILTER), one content panel swapped per tab, no scrolling wall of rows. */
final class RevUi {
    interface Host { void changed(); void close(); void unload(); }

    private static final int BG = 0xF00E1013, CARD = 0xFF171A1F, EDGE = 0xFF262B32;
    private static final int ACCENT = 0xFFFF7A3D, TEXT = 0xFFE8EAED, DIM = 0xFF8B929B;

    final LinearLayout root;
    final View header;
    private final Context ctx;
    private final Host host;
    private final LinearLayout tabStrip;
    private final FrameLayout content;
    private final TextView[] tabBtns;
    private int activeTab = 0;

    RevUi(Context c, Host h) {
        ctx = c; host = h;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(BG, ACCENT, 16));

        LinearLayout headerRow = new LinearLayout(c);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(dp(14), dp(10), dp(10), dp(6));
        TextView title = label("REVOLT.EXE", 16, ACCENT, true);
        title.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        headerRow.addView(title, tlp);
        TextView close = label("✕", 16, DIM, true);
        close.setPadding(dp(10), dp(4), dp(10), dp(4));
        close.setOnClickListener(v -> host.close());
        headerRow.addView(close);
        root.addView(headerRow);
        header = headerRow;   // draggable surface; EspService wires its touch listener onto this

        tabStrip = new LinearLayout(c);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabStrip.setPadding(dp(10), dp(0), dp(10), dp(4));
        root.addView(tabStrip);

        content = new FrameLayout(c);
        ScrollView sc = new ScrollView(c);
        sc.addView(content);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(sc, clp);

        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setPadding(dp(14), dp(6), dp(14), dp(12));
        TextView reset = label("RESET", 12, DIM, true);
        reset.setOnClickListener(v -> { Cfg.reset(); host.changed(); rebuild(); });
        TextView unload = label("UNLOAD", 12, 0xFFFF6B5E, true);
        unload.setPadding(dp(16), 0, 0, 0);
        unload.setOnClickListener(v -> host.unload());
        footer.addView(reset);
        footer.addView(unload);
        root.addView(footer);

        String[] names = {"ESP", "RADAR", "FILTER"};
        tabBtns = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView b = label(names[i], 13, DIM, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, -2, 1f);
            blp.setMargins(dp(2), 0, dp(2), 0);
            b.setLayoutParams(blp);
            b.setOnClickListener(v -> { activeTab = idx; rebuild(); });
            tabBtns[i] = b;
            tabStrip.addView(b);
        }
        rebuild();
    }

    private void rebuild() {
        for (int i = 0; i < tabBtns.length; i++) {
            boolean on = i == activeTab;
            tabBtns[i].setBackground(on ? rounded(0x33FF7A3D, ACCENT, 9) : null);
            tabBtns[i].setTextColor(on ? ACCENT : DIM);
        }
        content.removeAllViews();
        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(6), dp(14), dp(10));
        switch (activeTab) {
            case 0:
                toggle(panel, "ESP enabled", "esp");
                toggle(panel, "Show name", "name");
                toggle(panel, "Show distance", "dist");
                colorRow(panel, "Enemy color", "enemyCol");
                colorRow(panel, "Friend color", "friendCol");
                colorRow(panel, "Teammate color", "teamCol");
                note(panel, "No camera-forward offset was confirmed for this dump, so this is a radar + name/distance list, not a box ESP.");
                break;
            case 1:
                toggle(panel, "Radar", "radar");
                slider(panel, "Radar range (m)", "radarRange", 20, 400);
                slider(panel, "Radar size (px)", "radarSize", 80, 260);
                break;
            case 2:
                slider(panel, "Max distance (m)", "maxDist", 20, 1000);
                toggle(panel, "Sort by nearest", "sortNear");
                toggle(panel, "Hide friends", "hideFriend");
                toggle(panel, "Hide teammates", "hideTeam");
                break;
        }
        content.addView(panel);
    }

    private void toggle(LinearLayout p, String label, String key) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView t = label(label, 14, TEXT, false);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(t, tlp);
        Switch sw = new Switch(ctx);
        sw.setChecked(Cfg.b(key));
        sw.setOnCheckedChangeListener((CompoundButton b, boolean on) -> { Cfg.set(key, on ? 1f : 0f); host.changed(); });
        row.addView(sw);
        p.addView(row);
    }

    private void slider(LinearLayout p, String label, String key, int min, int max) {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(8), 0, dp(4));
        TextView t = label(label + "  (" + Cfg.i(key) + ")", 13, DIM, false);
        col.addView(t);
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(max - min);
        sb.setProgress(Cfg.i(key) - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                if (!user) return;
                Cfg.set(key, (float) (v + min));
                t.setText(label + "  (" + (v + min) + ")");
                host.changed();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(sb);
        p.addView(col);
    }

    private void colorRow(LinearLayout p, String label, String key) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView t = label(label, 14, TEXT, false);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(t, tlp);
        for (int i = 0; i < Cfg.COL.length; i++) {
            final int idx = i;
            View swatch = new View(ctx);
            int sz = dp(22);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sz, sz);
            lp.setMargins(dp(4), 0, dp(4), 0);
            GradientDrawable g = new GradientDrawable();
            g.setColor(Cfg.COL[i]);
            g.setCornerRadius(dp(6));
            if (Cfg.i(key) == i) g.setStroke(dp(2), Color.WHITE);
            swatch.setBackground(g);
            swatch.setLayoutParams(lp);
            swatch.setOnClickListener(v -> { Cfg.set(key, (float) idx); host.changed(); rebuild(); });
            row.addView(swatch);
        }
        p.addView(row);
    }

    private void note(LinearLayout p, String text) {
        TextView t = label(text, 11, DIM, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        t.setLayoutParams(lp);
        p.addView(t);
    }

    private int dp(float v) { return (int) (v * ctx.getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, int col, boolean bold) {
        TextView v = new TextView(ctx);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(col);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }
}
