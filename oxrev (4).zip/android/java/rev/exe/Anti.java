package rev.exe;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Debug;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.security.MessageDigest;

/** cheap integrity/anti-tamper gate: signature pin + debugger/frida smell test. Not real RASP -- raises the floor
 *  for a script-kiddie repack, nothing more. No root-detection on purpose (this needs root to run its core anyway). */
final class Anti {
    private static final String RELEASE_CERT_SHA256 = ""; // FILL: paste your release cert sha256 before shipping, empty = pin disabled

    static boolean looksTampered(Context ctx) {
        return !signatureOk(ctx) || debuggerAttached() || tracerAttached() || fridaSmell();
    }

    private static boolean signatureOk(Context ctx) {
        if (RELEASE_CERT_SHA256.isEmpty()) return true;
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES);
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            for (Signature s : pi.signatures) {
                byte[] d = md.digest(s.toByteArray());
                StringBuilder sb = new StringBuilder();
                for (byte x : d) sb.append(String.format("%02x", x));
                if (sb.toString().equalsIgnoreCase(RELEASE_CERT_SHA256)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static boolean debuggerAttached() {
        return Debug.isDebuggerConnected() || Debug.waitingForDebugger();
    }

    private static boolean tracerAttached() {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/status"))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("TracerPid:")) return !line.substring(10).trim().equals("0");
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static boolean fridaSmell() {
        String[] paths = {
                "/data/local/tmp/frida-server", "/data/local/tmp/re.frida.server",
                "/sdcard/frida-server", "/data/local/tmp/frida-gadget.so"
        };
        for (String p : paths) if (new File(p).exists()) return true;
        try {
            File task = new File("/proc/self/task");
            File[] ids = task.listFiles();
            if (ids != null) for (File id : ids) {
                File comm = new File(id, "comm");
                if (!comm.exists()) continue;
                try (BufferedReader r = new BufferedReader(new FileReader(comm))) {
                    String name = r.readLine();
                    if (name != null && (name.contains("gum-js-loop") || (name.contains("gmain") && name.contains("frida")))) return true;
                }
            }
        } catch (Exception ignored) {}
        return portOpen(27042) || portOpen(27043);
    }

    private static boolean portOpen(int port) {
        try (java.net.Socket s = new java.net.Socket()) {
            s.connect(new java.net.InetSocketAddress("127.0.0.1", port), 150);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
