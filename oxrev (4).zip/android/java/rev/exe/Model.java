package rev.exe;

import java.util.ArrayList;

/** Pure Java: protocol parser. No camera forward/FOV offsets were confirmed in this dump -> no world-to-screen ESP,
 *  radar + distance list only (needs positions alone). */
final class Player {
    long obj;
    int flags;                 // 1 local, 2 friend, 4 teammate
    float x, y, z;
    String name = "";
    boolean local() { return (flags & 1) != 0; }
    boolean friendly() { return (flags & 2) != 0; }
    boolean teammate() { return (flags & 4) != 0; }
}

final class Snap {
    boolean ok;
    String status = "";
    boolean haveLocal;
    float lx, ly, lz;
    Player[] players = new Player[0];
    long t;
}

final class Model {
    static volatile Snap snap = status("starting");

    static Snap status(String s) {
        Snap n = new Snap();
        n.status = s.length() > 90 ? s.substring(0, 90) : s;
        n.t = System.nanoTime();
        return n;
    }

    /** S|ok|haveLocal|lx,ly,lz|obj,flags,x,y,z,name;...   or   N|status */
    static Snap parse(String line) {
        if (line.startsWith("N|")) return status(line.substring(2));
        try {
            String[] f = line.split("\\|", -1);
            if (f.length < 4 || !f[0].equals("S")) return status(line);
            Snap s = new Snap();
            s.ok = true;
            s.status = f[1];
            s.haveLocal = f[2].equals("1");
            String[] lp = f[3].split(",", -1);
            if (lp.length == 3) { s.lx = Float.parseFloat(lp[0]); s.ly = Float.parseFloat(lp[1]); s.lz = Float.parseFloat(lp[2]); }
            s.t = System.nanoTime();
            ArrayList<Player> ps = new ArrayList<>();
            if (f.length >= 5 && !f[4].isEmpty()) {
                for (String e : f[4].split(";")) {
                    String[] q = e.split(",", 6);
                    if (q.length < 6) continue;
                    Player p = new Player();
                    p.obj = Long.parseLong(q[0]);
                    p.flags = Integer.parseInt(q[1]);
                    p.x = Float.parseFloat(q[2]); p.y = Float.parseFloat(q[3]); p.z = Float.parseFloat(q[4]);
                    p.name = q[5];
                    ps.add(p);
                }
            }
            s.players = ps.toArray(new Player[0]);
            return s;
        } catch (Exception e) {
            return status("parse error: " + line);
        }
    }

    static void publish(Snap n) { snap = n; }

    static float dist(Snap s, Player p) {
        float dx = p.x - s.lx, dy = p.y - s.ly, dz = p.z - s.lz;
        return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
